import Web3 from 'web3';
import TronWeb from 'tronweb';

export const initWeb3 = () => new Web3(window.ethereum);
export const initTronWeb = () => new TronWeb({ fullHost: 'https://api.trongrid.io' });