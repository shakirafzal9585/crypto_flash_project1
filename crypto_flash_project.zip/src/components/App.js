import React, { useState } from 'react';
import Web3 from 'web3';
import TronWeb from 'tronweb';

const App = () => {
  const [recipient, setRecipient] = useState('');
  const [amount, setAmount] = useState('');
  const [network, setNetwork] = useState('ethereum');
  
  // Ethereum USDT logic
  const sendEthereum = async () => {
    // Your Web3 Ethereum logic here
  };
  
  // TRON USDT logic
  const sendTron = async () => {
    // Your TronWeb TRON logic here
  };

  return (
    <div>
      <h2>Crypto Flash - USDT Sender</h2>
      <input type="text" placeholder="Recipient Address" value={recipient} onChange={(e) => setRecipient(e.target.value)} />
      <input type="number" placeholder="Amount" value={amount} onChange={(e) => setAmount(e.target.value)} />
      <button onClick={sendEthereum}>Send Ethereum USDT</button>
      <button onClick={sendTron}>Send TRON USDT</button>
    </div>
  );
};

export default App;